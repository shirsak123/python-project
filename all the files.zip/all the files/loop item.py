L=[22,33,44,55]
total=0
for number in L:
    total += number
print(total)


L=[22,33,44,55]
total=0
for i in range(len(L)):
    total += L[i]
print(total)

fruits=["apple","orange","mango"]
if "apple" in fruits:
    print("fruits")
else:
    print("not fruits")



L1=["apple","orange","mango",1,2]
if
#string formatting
#
# name="shirsak"
# age=19
# print("Hello %s. you are %s years old." % (name,age))
# weight=54
# print("name:%s,age:%s,weight:%s" % (name,age,weight))
#


# name="shirsak"
# age=19
# weight=54
# print("name:%s,age:%d,weight:%d" % (name,age,weight))
# print("name:%s,age:%d,weight:%03d" % (name,age,weight))

pi = 3.141592653589793
print("pi is %.2f" % pi)
print("pi is %.4f" % pi)
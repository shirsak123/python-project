# def add ():
#     sum_ =a+b
#     return sum_
# a=2
# b=3
# print (add())
#
# def sum(a,b):
#     sum_=a+b
#     return sum_
# z=sum(3,5)
# print(z)
#
# def num(a):
#     a=a%2
#     return a
# b=int(input("enter a number"))                     #to print it is odd or even
# c=num(b)
# if c==0:
#     print("it is even")
# else:
#     print("it is odd")
#

b=input("enter a letter")
def check_string(c):
    if c.isupper():
        print("it is in upper case")
    else:
        print("it is in lower case")
check_string(b)

b=int("enter a row")
c=int("enter a column")
a=[[1,2,3] [4,5,6][7,8,9]]
for i in range(len(a)):
    for j in range(len(a[i])):
        print(a[i][j])





















a={"a":100, "b":200}
b={"x":300, "y":200}
c=a.copy()    #to merge a dictionary in third empty variable
c.update(b)
print(c)














a=int(input("enter a number"))
if a==1:
    print("It is sunday and "+""+"its a holiday")
elif a==2:
    print("it is monday")
elif a==3:
    print("it is tuesday")
elif a==4:
    print("it is wednesday")
elif a==5:
    print("it is thursday")
elif a==6:
    print("it is friday")
elif a==7:
    print("it is saturday and "+""+"it is holiday")
else:
    print("please input any number from 1 to 7 for the result")

a = int(input("enter a number"))
while (x <= 20):
    x = 1
    print((str(a) + "*" + str(x) + "=" + str(a * x)))
    print((str(a) + "*" + str(x) + "=" + str(a * x)))
x = x + 1








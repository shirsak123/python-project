a = 10

b = 20

if not a>b:

      print(f"{a} is less than {b}")
else:
        print(f"{b} is less than {a}")




import tkinter as tk
r=tk.Tk()
r.title("counting seconds")
r.wm_title("code with shirsak")
button=tk.Button(r,text="my name is shirsak",width=25,height=25,command=r.destroy)
button.pack()
r.mainloop()


from tkinter import*
master=Tk()
w=Canvas(master,width=40,height=60)
w.pack()
canvas_height=20
canvas_width=200
y=int(canvas_height/2)
w.create_line(0,y,canvas_width,y)
mainloop()

from tkinter import*
master=Tk()
var1=IntVar()
Checkbutton(master,text="male",variable=var1).grid(row=0,sticky=W)
var2=IntVar()
Checkbutton(master,text="female",variable=var2).grid(row=1,sticky=W)
mainloop()




from tkinter import *
Master = Tk()
Label(Master, text='First Name =').grid(row=0, sticky=W)
Label(Master, text='Middle Name =').grid(row=1)
Label(Master, text='Last Name =').grid(row=2, sticky=W)
E1 = Entry(Master, foreground="green", font=("cooper black", 10, 'normal'))
E2 = Entry(Master, background='orange', font=("cooper black", 10, 'normal'))
E3 = Entry(Master, bg='yellow', fg='blue', font=("cooper black", 10, 'normal'))

def change_text():
    print("First Name= %s \n Middle Name= %s \n Last Name= %s" % (E1.get(), E2.get(), E3.get()))
    replace = str(f"{E1.get()} {E2.get()} {E3.get()} ")
    New_Label['text'] = replace


BTN = Button(Master, text='Display', height=2, width=10, font=("Arial", 10, 'bold'), command=change_text)
New_Label = Label(Master, fg="red", text='This is a sample text.', font=('chiller', 15, 'bold'))
E1.grid(row=0, column=1)
E2.grid(row=1, column=1)
E3.grid(row=2, column=1)
BTN.grid(row=3, column=1)
New_Label.grid(row=4, column=1)
mainloop()






from tkinter import*


root=Tk()
frame=Frame(root)
frame.pack()
bottomframe=Frame(root)
bottomframe.pack(side=BOTTOM)
redbutton = Button(frame,text="Red",fg="red")
redbutton.pack(side=LEFT)
greenbutton=Button(frame,text="Brown",fg="brown")
greenbutton.pack(side=LEFT)
bluebutton=Button(frame,text="Blue",fg="blue")
bluebutton.pack(side=LEFT)
blackbutton=Button(bottomframe,text="Black",fg="black")
blackbutton.pack(side=BOTTOM)
root.mainloop()


from tkinter import*
from tkinter import messagebox

top = Tk()
def helloCallback():
    messagebox.showinfo("Hello Python","Hello World")
def showText():
    label=Label(top,fg="green",text="This is simple text")
    label.pack()

B=Button(top,text="Hello",command= helloCallback)
ex=Button(top,text="Destroy Button",width=25,command=top.destroy)

b2=Button(top,text="write in label",command=showText)

B.pack()
ex.pack()
b2.pack()

top.mainloop()

from tkinter import*
top=Tk()
from random import randint


def ran_int():
    replace=str(f"{randint(1,6)}")
    New_Label["text"]=replace

b2 = Button(top, text="Dice", command=ran_int)
b2.pack()
New_Label = Label(top, fg="green", text=f"{randint(1, 6)}")

New_Label.pack()
top.mainloop()


from tkinter import*
top=Tk()




a=""
for b in range(5):
    b=input("enter a number")
    a=a+b
print(a)

n=0
while n<5:
    print(n)
    if n==2:
        break
    n=n+1


for n in range(10):
    print(n)
    if n==6:
        break



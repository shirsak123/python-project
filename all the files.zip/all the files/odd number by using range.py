for i in range(99,0,-2):
    print(i)
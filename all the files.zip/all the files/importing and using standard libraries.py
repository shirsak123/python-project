import math

print (math.cos(0))
print (math.factorial(5))
print (math.gcd(12,6))



import datetime

print(datetime.datetime.now())
print(datetime.datetime.now().year)
print(datetime.datetime.now().month)
print(datetime.datetime.now().day)
print(datetime.datetime.now().hour)
print(datetime.datetime.now().minute)
print(datetime.datetime.now().second)


import random
print(random.randint(1,1000))


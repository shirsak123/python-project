#create a list containing number from 1 to 5
# l=[]
# for i in range(1,6):
#     l.append(i)
# print(l)

# #using list comprehension         ################### OR

# l=[i for i in range(1,6)]
# print(l)

#take 5 number a input and put in list

# l=[]
# for i in range(5):
#     num=int(input("enter a number:"))
#     l.append(num)
# print(l)
#                                                 ################# OR

#list comprension

# l=[int(input("enter a number:")) for i in range(5)]
# print(l)


#put the squares of all the numbers of a list into another list

# l1=[1,2,3,4]
# l2=[]
# for num in l1:
#     l2.append(num**2)
# print(l2)

#       OR

#list comprehension
# l1=[1,2,3,4]
# l2=[num**2 for num in l1]
# print(l2)


#put the even number of a list into another list

# l1=[1,2,3,4]
# l2=[]
# for num in l1:
#     if num % 2 ==0:
#         l2.append(num)
# print(l2)
#

#        OR

# list comprehension

# l1=[1,2,3,4]
# l2=[]
# l2=[num for num in l1 if num % 2 == 0]
# print(l2)

#put 5 random number in list

# from random import randint
# l=[]
# for i in range(5):
#     l.append(randint(1,10))
# print(l)

#  OR

# list comprehension

from random import randint
l=[randint(1,10)for i in range(5)]    # gives random output
print(l)

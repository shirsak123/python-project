# import turtle
# #draw square or rectangle
# #
# t=turtle.Turtle()
# t.pencolor("green")
# for i in range(2):
#      t.begin_fill()
#      t.forward(100)
#      t.left(90)
#      t.forward(100)
#      t.left(90)
#      t.fillcolor("red")
# t.end_fill()
# t.penup()
# t.goto(50,100)
# t.pendown()
# t.begin_fill()
# t.shape("arrow")
# t.circle(100)
# t.fillcolor("green")
# t.end_fill()
# t.penup()
# t.goto(100,200)
# t.pendown()
# t.pensize(100)
# t.begin_fill()
# t.shape("arrow")
# for i in range(2):
#      t.begin_fill()
#      t.forward(100)
#      t.right(90,)
#      t.forward(100)
#      t.left(90)
#      t.fillcolor("red")
#
#
#
#
#
#
#
# t=turtle.Turtle()
# for j in range(10):
#   t.circle(5*j)
#   t.up()
#   t.sety((10*j)*(-1))
#   t.down()
#   t.fillcolor("yellow")
# turtle.done()



import turtle
car = turtle.Turtle()
car.color("red")
car.penup()
car.goto(-200,0)
car.pendown()
car.begin_fill()
for i in range(2):
 car.begin_fill()
 car.forward(300)
 car.left(90)
 car.forward(90)
 car.left(90)
car.fillcolor("red")
car.end_fill()



car.penup()
car.goto(150,45)
car.pendown()

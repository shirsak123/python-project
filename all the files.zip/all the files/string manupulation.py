a=input("enter your name")
b=a.upper()                       #to cange the given input in upper case
print(b)
for i in range (len(b)):                   #to iterate the input
    print(b[i])



a="today is monday"
b=a.split()
c="".join(b)
print(c)
s=(a.replace("today is monday","yesterday was monday"))
j=s.split()
k="".join(j)
print(k)
y="#".join(b)
print(y)
l=y.split()
h="".join(a)
print(h)


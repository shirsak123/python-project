a=input("enter first number:")
b=input("enter second number:")
x=int(a)+int(b)
y=int(a)-int(b)
print("the sum is"+" "+str(x))
print("the difference is"+" "+str(y))

l=input("enter a length of a rectangle:")
b=input("enter a breadth of a rectangle:")
Area=int(l)*int(b)
perimeter=2*(int(l)+int(b))
print("The area is "+" "+str(Area))
print("The primeter is "+" "+str(perimeter))

a=input("enter your name:")
print("Hello"+" "+str(a)+","+"have a nice day!")

x=int(input("enter a value of x"))
y=int(input("enter a value of y"))
a=x**3+3*x**2*y+3*x*y**2+y**3
print(int(a))


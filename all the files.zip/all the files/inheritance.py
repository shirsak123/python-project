class person():
    def __init__(self,name,address,phone):
        self.name = name
        self.address = address
        self.phone = phone
    def introduce (self):
        return "Hi my name is"+" "+self.name


class Teacher (person):
    def __init__(self,name,address,phone,subject):
        person.__init__(self,name,address,phone)                     #inheritance from person
        self.subject = subject


class student(person):
    def __init__(self,name,address,phone,group):
        person.__init__(self,name,address,phone)                      #inheritance from person
        self.group = group

p=person("shirsak","KTM",123)
print(p.name)
print(p.introduce())

t=Teacher("shirsak","Nyc",123,"python")
print(t.name,t.subject)
print(t.introduce())

s=student("shirsak","pkr",212,"CS101")
print(s.name,s.group)
print(s.introduce())



#create a class Animal , with function and a variable with animal name,
#can breath,
#can run
#can speak

#create child class human,
   #with one extra function, can think

#create child class to animal called dog
 #with one extra function, is loyal

#now, using OOP,print,human can think , similarly human can breath,run and speak and also for dog,
#print dog is loyal, and can breath run and speak,
#using concept of inheritance,



class animal():
    def __init__(self,name,breath,run,speak):
        self.name = name
        self.breath = breath
        self.run = run
        self.speak = speak
    def can_breath(self):
        return self.name+" "+"can breath"
    def can_run(self):
        return self.name+" "+"can run"
    def can_speak(self):
        return self.name+" "+"can speak"


class human(animal):
    def __init__(self,name,breath,run,speak,think):
        animal.__init__(self,name,breath,run,speak)
        self.think = think
    def can_think(self):
        return self.name+" "+"can think"

class dog(animal):
    def __init__(self,name,breath,run,speak,loyal):
        animal.__init__(self,name,breath,run,speak)
        self.loyal = loyal
    def is_loyal(self):
        return self.name+" "+"is loyal"

h=human("hari","a","b","c","d")
print(h.can_think())
print(h.can_breath())
print(h.can_run())
print(h.can_speak())

d=dog("bunjo","v","m","o","q")
print(d.can_speak())
print(d.is_loyal())
print(d.can_speak())
print(d.can_run())
print(d.can_breath())

a=animal("tiger","r","y","i")
print(a.can_breath())
print(a.can_run())
print(a.can_speak())



#or


class Animal():
    def __init__(self, name):
        self.N = name

    def can_breath(self):
        return f'\n{self.N} can breath.'

    def can_run(self):
        return f"{self.N} can run."

    def can_speak(self):
        return f"{self.N} can speak."


class Human(Animal):

    def can_think(self):
        return f"{self.N} can think."


class Dog(Animal):

    def is_loyal(self):
        return f"{self.N} is loyal."


A1 = Animal("leopard")
print(A1.can_breath())
print(A1.can_run())
print(A1.can_speak())

H1 = Human("Brad")
print(H1.can_breath())
print(H1.can_run())
print(H1.can_speak())
print((H1.can_think()))

D1 = Dog("Tom")
print(D1.can_breath())
print(D1.can_run())
print(D1.can_speak())
print(D1.is_loyal())














# l=[1,2,3,4,5,6,7,8,9]
# print(l[-5:-2])

# l=[22,33,12,32,43,77]
# print(l[1:])
#
# print(l[:3])
#
# print(l[1:5])
#
# print(l[1:5:2])     #steps
#
# print(l[:])
#
# print(l[::])
#
# print(l[:: -1])


#Slicing tupples

# l=[22,33,12,32,43,77]
# print(l[0])
#
# print(l[1:5])
#
# print(l[1:])
#
# print(l[:3])     #steps
#
# print(l[1:5:2])
#
# print(l[::-2])


#slicing string

# s="python is for legends"
#
# print(s[0])
#
# print(s[1:5])
#
# print(s[1:])
#
# print(s[:3])
#
# print(s[1:5:2])
#
# print(s[::-1])








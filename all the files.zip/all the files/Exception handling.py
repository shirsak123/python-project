# success = False
# while success == False:              #it loop the invalid output untile valid data is given
#     try:
#         radius = int(input("Enter radius"))
#         area = 3.14*(radius)**2
#         print(area)
#         success = True
#     except:
#         print("Invalid value for radius")                    #if the value is invalid it print except
#
#
# #create a function divide with two paramater a,b
# #now it should return the divided value like a/b,
# #now if the input form user i.e b is 0, our program should produce a nice exception error,
#
# def num(a, b):
#     x= a / b
#     return (x)
# success = False
# while success == False:
#     try:
#         a=int(input("enter the divident "))
#         b=int(input("enter a diviser"))
#         f=num(a,b)
#         print(f)
#     except:
#         print("you have given invalid error")

#use exception handling to report out of bound error a=[1,2,3]
#print(5) //gives error now to use try catch to handle these errors.

try:
    b=5/0
    a=[1,2,3]
    print(a[5])
except(IndexError,ZeroDivisionError,IndentationError):
    print("there was a error in your code")
names = ["John","Sam","anna","ben","jeff"]
maths = [88,77,67,87,90]
english = [86,67,65,78,80]
for i in range (len(names)):
    if names[i]=="anna":
        temp=i
        print("marks of anna is"+maths(temp))
        print("marks of anna is" + english(temp))



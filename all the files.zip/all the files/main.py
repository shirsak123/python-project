import operation


print(operation.add(1,2))
print(operation.subtract(4,2))
print(operation.multiply(6,2))
print(operation.add(9,2))


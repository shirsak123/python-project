file=open("file.txt","r")
print(file.read())
file.close()                                   #o read a file


file=open("file.txt","r")
lines=(file.readlines())

print(lines)

file.close()



file=open("file.txt","r")
lines=file.readlines()
for line in lines:
 print(line)
file.close()


file=open("file2.txt","w")
for i in range(5):                                                  #to write a file
    file.write(str(i))
    file.write("\n")
file.close()


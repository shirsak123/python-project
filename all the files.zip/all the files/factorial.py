a=int(input("enter a number"))
x =1
while(a>0):
    x=x*a
    a=a-1
print(x)


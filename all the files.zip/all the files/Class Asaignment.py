#wap to calculate Avg marks,total marks,higest marks,topper name,from a file using function.


file=open("file.txt","r")
lines=file.readlines()
for line in lines:
 print(line)
file.close()



# #public class,private class and protected
# class A():6
#








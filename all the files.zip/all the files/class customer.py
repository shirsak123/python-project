#class customer
#ceate a class student, and find the avg marks,Total maks ,and also the topper name,
# pass the basic information from constructor and for specific infos use function.


class Student():
    def __init__(self, name, address):
        self.N = name
        self.A = address
        self.Sub_Name = ['English', 'Nepali', 'Maths']
        self.User_Marks = []

    def print_info(self):
        print('Your name and address is :' + self.N, self.A)

    def get_marks(self):
        for i in range(len(self.Sub_Name)):
            m = int(input("enter the marks "))
            self.User_Marks.append(m)

    def display_marks(self):
        Total = sum(self.User_Marks)
        Average = Total / len(self.Sub_Name)
        print("Your average marks is", Average)


First_S = Student("Shirsak", "KTM") # This is creation of object called x
First_S.print_info()
First_S.get_marks()
First_S.display_marks()

class Course():
    def __init__(self, name, course_name, course_code):
        self.CN = course_name
        self.CC = course_code
        self.N = name
        self.a = int(input("Enter the marks you have scored in English."))
        self.b = int(input("Enter the marks you have scored in Nepali."))
        self.c = int(input("Enter the marks you have scored in Physics."))

    def get_info(self):
        print(f"Name: {self.N} \n" f"Faculty: {self.CN} \n" f"Code: {self.CC}")


class Student(Course):

    def exposing_marks(self):
        total = self.a + self.b + self.c
        average = total / 3
        print(f"Average Marks: {average}")


St1 = Student("shirsak shrestha", "Science", "38")
St1.get_info()
St1.exposing_marks()








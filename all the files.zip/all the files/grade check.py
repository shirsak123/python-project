grade=float(input("enter a grade"))
if(grade>=60):
    print("the grade is B")
elif(grade>=70):
    print("the grade is B+")
elif(grade>=80):
    print("the grade is A")
elif grade>=90:
    print('garde is A+')
else:
    print('you failed')





n = 1#set counter
while n<= 100:
    print(n)
    n = n + 2

a=int(input("enter a number"))
if (a%2==0):
    print("it is even")
else:
    print("it is odd")

n=5
while n<=50:
    print(n)
    n=n + 5



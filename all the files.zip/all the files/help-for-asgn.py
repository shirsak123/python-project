# from tkinter import*
# master=Tk()
# master.title("Welcome to my world!")
# master.geometry('400x300')
# master.configure(bg="#ed1800")
# name=Label(master,text="Full name").pack()
# no=Label(master,text="Contact Number").pack()
# lbl=Label(master,text="empty")
# lbl.pack(expand=True,fill=BOTH)
# frame=Frame(master,bg="orange")
# frame.pack()
# name_entry=Entry(frame)
# name_entry.pack()
# no_entry=Entry(frame)
# no_entry.pack()
#
# def btn_clk():
#
#     res="Welcome "+name_entry.get() +" "+"your number is"+" "+no_entry.get()
#     lbl.configure(text=res)
#
# def write():
#     file=open("b.txt","a")
#     res = "Welcome " + name_entry.get()+" " + "your number is" + " " +no_entry.get()+"\n"
#     file.write(res)
#     file.close()
# def read():
#     file=open("b.txt","r")
#     x=file.readline()
#     lbl.configure(text=x)
#
# btn=Button(master,text="Submit",command=btn_clk)
# rbtn=Button(master,text="read",command=read)
# wbtn=Button(master,text="write",command=write)
# btn.pack(expand=TRUE,fill=BOTH)
# rbtn.pack(expand=TRUE,fill=BOTH)
# wbtn.pack(expand=TRUE,fill=BOTH)
# master.mainloop()

import tkinter as tk
class Main(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self._frame = None
        self.switch_frame(Login)

    def switch_frame(self,frame_class):
        new_frame=frame_class(self)
        if self._frame is not None:
            self._frame.destroy()
        self._frame=new_frame
        self._frame.pack()
class Login(tk.Frame):
    def __init__(self,master):
        tk.Frame.__init__(self,master)
        tk.Label(self,text="This is the login page").pack()
        tk.Button(self,text="Open Employee Page",command=lambda:master.switch_frame(Employee)).pack()
        tk.Button(self,text="Open Department Page",command=lambda:master.switch_frame(Department)).pack()
        tk.Button(self,text="Open College Page",command=lambda:master.switch_frame(College)).pack()

class Employee(tk.Frame):
    def __init__(self,master):
        tk.Frame.__init__(self,master)
        tk.Label(self,text="This is Employee page ").pack()
        tk.Button(self,text="Are you done then return to Login page again",command=lambda :master.switch_frame(Login)).pack()

class Department(tk.Frame):
    def __init__(self,master):
        tk.Frame.__init__(self,master)
        tk.Label(self,text="This is Department page ").pack()
        tk.Button(self,text="Are you done then return to Login page again",command=lambda :master.switch_frame(Login)).pack()

class College(tk.Frame):
    def __init__(self,master):
        tk.Frame.__init__(self,master)
        tk.Label(self,text="This is College page ").pack()
        tk.Button(self,text="Are you done then return to Login page again",command=lambda :master.switch_frame(Login)).pack()

yes=Main()
yes.mainloop()
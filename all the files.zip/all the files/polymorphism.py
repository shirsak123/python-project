class person():
    def __init__(self,name,address,phone):
        self.name = name
        self.address = address
        self.phone = phone
    def introduce(self):
        return "Hi my name is"+self.name

class teacher(person):
    def __init__(self,name,address,phone,subject):
        person.__init__(self,name,address,phone)
        self.subject = subject

    def introduce(self):
        return "Hi my name is"+" "+self.name+".I am a teacher"    #overriding / redefining the parent method

t=teacher("shirsak","a","b","python")
print(t.name,t.subject)
print(t.introduce())





#create a class called calculation #create a function add a+b if two variable or a+b+c if three variable and return it.must behave polymorphism where two parameter or three parameteras can be paseed
class Calculation():
    def add(self,a,b,c=0):
       self.A =a
       self.B =b
       self.C =c
       return(a+b+c)
H=Calculation()
print(H.add(5,8,9))                 #you can give either two or three number as a input